import { getDeviceId, getLang, setLang, getRemainingUsage, decrementUsage, saveToHistory, getHistory } from "../utils/storage.js";
import { summarize, askQuestion, analyzeBias, getVotes, submitVote } from "../utils/api.js";
import { fetchRelatedSources } from "../utils/rss.js";

const TR = {
  summarize: "Özetle", summarizing: "Özetleniyor...",
  summary_title: "Özet", sources_title: "Diğer Kaynaklar",
  back: "Geri", go_premium: "Premium'a Geç",
  daily_limit: "Günlük 10 özet hakkın doldu.",
  usage_remaining: (n) => `Bugün ${n} özet hakkın kaldı.`,
  not_article: "Bu sayfa bir haber makalesi değil.",
  error_generic: "Bir hata oluştu. Tekrar dene.",
  copy: "Kopyala", copied: "Kopyalandı!",
  twitter_share: "𝕏 Paylaş",
  qa_label: "Soru Sor",
  qa_placeholder: "Bu haber hakkında bir şey sor...",
  bias_btn: "⚖ Taraflılık Analizi",
  bias_loading: "Analiz ediliyor...",
  bias_title: "TARAFLILIK ANALİZİ",
  bias_left: "Sol", bias_right: "Sağ",
  bias_objective: "Nesnel", bias_emotional: "Duygusal",
  bias_labels: ["Güçlü sol", "Sol eğilimli", "Merkez", "Sağ eğilimli", "Güçlü sağ"],
  bias_emo_labels: ["Nesnel", "Kısmen duygusal", "Duygusal"],
  clickbait_title: "CLICKBAIT MI?",
  clickbait_yes: "👎 Clickbait",
  clickbait_no: "👍 Değil",
  clickbait_first: "İlk oyu sen ver",
  clickbait_stats: (y, n) => `${y} clickbait · ${n} değil`,
};
const EN = {
  summarize: "Summarize", summarizing: "Summarizing...",
  summary_title: "Summary", sources_title: "Other Sources",
  back: "Back", go_premium: "Go Premium",
  daily_limit: "You've used all 10 free summaries today.",
  usage_remaining: (n) => `${n} summaries left today.`,
  not_article: "This page doesn't look like a news article.",
  error_generic: "Something went wrong. Please try again.",
  copy: "Copy", copied: "Copied!",
  twitter_share: "𝕏 Share",
  qa_label: "Ask a Question",
  qa_placeholder: "Ask something about this article...",
  bias_btn: "⚖ Bias Analysis",
  bias_loading: "Analyzing...",
  bias_title: "BIAS ANALYSIS",
  bias_left: "Left", bias_right: "Right",
  bias_objective: "Objective", bias_emotional: "Emotional",
  bias_labels: ["Far left", "Left-leaning", "Center", "Right-leaning", "Far right"],
  bias_emo_labels: ["Objective", "Somewhat emotional", "Emotional"],
  clickbait_title: "CLICKBAIT?",
  clickbait_yes: "👎 Clickbait",
  clickbait_no: "👍 Not clickbait",
  clickbait_first: "Be the first to vote",
  clickbait_stats: (y, n) => `${y} clickbait · ${n} not clickbait`,
};

let lang = "tr";
let t = TR;
let currentArticle = null;
let currentSummary = "";

function show(id) {
  ["mainView", "loadingView", "resultView", "limitView"].forEach((v) =>
    document.getElementById(v).classList.toggle("hidden", v !== id)
  );
}

function renderClickbait({ total, clickbait, userVote }) {
  const notClickbait = total - clickbait;
  document.getElementById("clickbaitLabel").textContent = t.clickbait_title;
  document.getElementById("voteYesBtn").textContent = `${t.clickbait_yes} (${clickbait})`;
  document.getElementById("voteNoBtn").textContent = `${t.clickbait_no} (${notClickbait})`;
  document.getElementById("clickbaitStats").textContent =
    total === 0 ? t.clickbait_first : t.clickbait_stats(clickbait, notClickbait);
  document.getElementById("voteYesBtn").classList.toggle("vote-active-yes", userVote === true);
  document.getElementById("voteNoBtn").classList.toggle("vote-active-no", userVote === false);
}

async function loadVotes() {
  if (!currentArticle?.url) return;
  const deviceId = await getDeviceId();
  const data = await getVotes({ url: currentArticle.url, deviceId });
  if (data) renderClickbait(data);
}

function applyTranslations() {
  document.getElementById("langBtn").textContent = lang === "tr" ? "EN" : "TR";
  document.getElementById("summarizeBtn").textContent = t.summarize;
  document.getElementById("backBtn").textContent = t.back;
  document.getElementById("premiumBtn").textContent = t.go_premium;
  document.getElementById("summaryLabel").textContent = t.summary_title;
  document.getElementById("qaLabel").textContent = t.qa_label;
  document.getElementById("qaInput").placeholder = t.qa_placeholder;
  document.getElementById("copyLabel").textContent = t.copy;
  document.getElementById("twitterBtn").textContent = t.twitter_share;
  document.getElementById("biasBtn").textContent = t.bias_btn;
  document.getElementById("biasSectionLabel").textContent = t.bias_title;
  document.getElementById("biasLeftLabel").textContent = t.bias_left;
  document.getElementById("biasRightLabel").textContent = t.bias_right;
  document.getElementById("biasObjectiveLabel").textContent = t.bias_objective;
  document.getElementById("biasEmotionalLabel").textContent = t.bias_emotional;
  document.getElementById("clickbaitLabel").textContent = t.clickbait_title;
  document.getElementById("voteYesBtn").textContent = t.clickbait_yes;
  document.getElementById("voteNoBtn").textContent = t.clickbait_no;
}

function renderBias({ political, emotional, note }) {
  const polPct = ((political + 100) / 200 * 100).toFixed(1);
  const emoPct = Number(emotional).toFixed(1);
  document.getElementById("biasPoliticalDot").style.left = `${polPct}%`;
  document.getElementById("biasEmotionalDot").style.left = `${emoPct}%`;

  const polIdx = political < -60 ? 0 : political < -20 ? 1 : political <= 20 ? 2 : political < 60 ? 3 : 4;
  const emoIdx = emotional < 35 ? 0 : emotional < 65 ? 1 : 2;
  document.getElementById("biasPoliticalValue").textContent = t.bias_labels[polIdx];
  document.getElementById("biasEmotionalValue").textContent = `${t.bias_emo_labels[emoIdx]} (%${Math.round(emotional)})`;
  document.getElementById("biasNote").textContent = note;
  document.getElementById("biasSection").classList.remove("hidden");
}

function renderResult({ summary, sources }) {
  document.getElementById("summaryText").textContent = summary;
  document.getElementById("biasSection").classList.add("hidden");
  document.getElementById("biasBtn").textContent = t.bias_btn;
  document.getElementById("biasBtn").disabled = false;
  document.getElementById("qaAnswer").classList.add("hidden");
  document.getElementById("qaAnswer").textContent = "";
  document.getElementById("qaInput").value = "";

  const sourcesList = document.getElementById("sourcesList");
  const sourcesLabel = document.getElementById("sourcesLabel");
  sourcesList.innerHTML = "";
  if (sources?.length) {
    sourcesLabel.textContent = t.sources_title;
    sourcesLabel.classList.remove("hidden");
    sources.forEach(({ title, link, source }) => {
      const li = document.createElement("li");
      const a = document.createElement("a");
      a.href = link;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = `${source ? `[${source}] ` : ""}${title}`;
      li.appendChild(a);
      sourcesList.appendChild(li);
    });
  } else {
    sourcesLabel.classList.add("hidden");
  }
  // Clickbait oy durumunu sıfırla ve yükle
  document.getElementById("clickbaitStats").textContent = t.clickbait_first;
  document.getElementById("voteYesBtn").classList.remove("vote-active-yes");
  document.getElementById("voteNoBtn").classList.remove("vote-active-no");
  show("resultView");
}

function renderHistory(items) {
  if (!items.length) return;
  const list = document.getElementById("historyList");
  list.innerHTML = "";
  items.forEach((item) => {
    const li = document.createElement("li");
    li.className = "history-item";
    li.title = item.title || item.summary;
    li.textContent = item.title || item.summary.slice(0, 60) + "...";
    li.addEventListener("click", () => {
      currentArticle = item.article;
      currentSummary = item.summary;
      renderResult(item);
    });
    list.appendChild(li);
  });
  document.getElementById("historySection").classList.remove("hidden");
  document.getElementById("historyLabel").textContent = lang === "tr" ? "Son Özetler" : "Recent Summaries";
}

async function init() {
  lang = await getLang();
  t = lang === "tr" ? TR : EN;
  applyTranslations();

  const remaining = await getRemainingUsage();
  document.getElementById("usageText").textContent = t.usage_remaining(remaining);

  // Önceki sonucu geri yükle
  const { lastResult } = await chrome.storage.local.get("lastResult");
  if (lastResult) {
    currentArticle = lastResult.article;
    currentSummary = lastResult.summary;
    renderResult(lastResult);
    loadVotes();
    return;
  }

  if (remaining === 0) { show("limitView"); document.getElementById("limitText").textContent = t.daily_limit; return; }

  const history = await getHistory();
  renderHistory(history);
  show("mainView");
}

document.getElementById("summarizeBtn").addEventListener("click", async () => {
  show("loadingView");
  document.getElementById("loadingText").textContent = t.summarizing;

  const article = await new Promise((res) =>
    chrome.runtime.sendMessage({ action: "getArticle" }, res)
  );

  if (!article) {
    alert(t.not_article);
    show("mainView");
    return;
  }

  const deviceId = await getDeviceId();
  const result = await summarize({ ...article, lang, deviceId });

  if (result.error === "limit") {
    show("limitView");
    document.getElementById("limitText").textContent = t.daily_limit;
    return;
  }
  if (result.error) {
    alert(t.error_generic);
    show("mainView");
    return;
  }

  await decrementUsage();
  currentArticle = article;
  currentSummary = result.summary;

  const sources = result.sources?.length
    ? result.sources
    : await fetchRelatedSources(article.title);

  const historyItem = { title: article.title, summary: result.summary, sources, article };
  await chrome.storage.local.set({ lastResult: historyItem });
  await saveToHistory(historyItem);

  renderResult(historyItem);
  loadVotes();
});

// Taraflılık Analizi
document.getElementById("biasBtn").addEventListener("click", async () => {
  if (!currentArticle) return;
  const btn = document.getElementById("biasBtn");
  btn.disabled = true;
  btn.textContent = t.bias_loading;

  const deviceId = await getDeviceId();
  const result = await analyzeBias({ ...currentArticle, lang, deviceId });

  btn.disabled = false;
  if (result.error === "limit") {
    btn.textContent = t.daily_limit;
    return;
  }
  if (result.error || result.political === undefined) {
    btn.textContent = t.error_generic;
    setTimeout(() => { btn.textContent = t.bias_btn; }, 2000);
    return;
  }

  btn.classList.add("hidden");
  renderBias(result);
});

// Kopyala
document.getElementById("copyBtn").addEventListener("click", async () => {
  if (!currentSummary) return;
  await navigator.clipboard.writeText(currentSummary);
  const label = document.getElementById("copyLabel");
  label.textContent = t.copied;
  setTimeout(() => { label.textContent = t.copy; }, 2000);
});

// Twitter paylaş
document.getElementById("twitterBtn").addEventListener("click", () => {
  if (!currentSummary) return;
  const text = encodeURIComponent(currentSummary.slice(0, 240) + " (AI Özet)");
  chrome.tabs.create({ url: `https://twitter.com/intent/tweet?text=${text}` });
});

// Soru Sor
document.getElementById("qaBtn").addEventListener("click", async () => {
  const question = document.getElementById("qaInput").value.trim();
  if (!question || !currentArticle) return;

  const btn = document.getElementById("qaBtn");
  btn.disabled = true;
  btn.textContent = "...";

  const deviceId = await getDeviceId();
  const result = await askQuestion({ ...currentArticle, lang, deviceId, question });

  btn.disabled = false;
  btn.textContent = "→";

  const answerEl = document.getElementById("qaAnswer");
  if (result.error === "limit") {
    answerEl.textContent = t.daily_limit;
  } else if (result.error) {
    answerEl.textContent = t.error_generic;
  } else {
    answerEl.textContent = result.answer;
  }
  answerEl.classList.remove("hidden");
});

document.getElementById("qaInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter") document.getElementById("qaBtn").click();
});

// Clickbait oylama
document.getElementById("voteYesBtn").addEventListener("click", async () => {
  if (!currentArticle?.url) return;
  const deviceId = await getDeviceId();
  const data = await submitVote({ url: currentArticle.url, deviceId, is_clickbait: true });
  if (data) renderClickbait(data);
});

document.getElementById("voteNoBtn").addEventListener("click", async () => {
  if (!currentArticle?.url) return;
  const deviceId = await getDeviceId();
  const data = await submitVote({ url: currentArticle.url, deviceId, is_clickbait: false });
  if (data) renderClickbait(data);
});

document.getElementById("backBtn").addEventListener("click", async () => {
  await chrome.storage.local.remove("lastResult");
  currentArticle = null;
  currentSummary = "";
  const history = await getHistory();
  renderHistory(history);
  show("mainView");
});

document.getElementById("langBtn").addEventListener("click", async () => {
  lang = lang === "tr" ? "en" : "tr";
  await setLang(lang);
  t = lang === "tr" ? TR : EN;
  await init();
});

document.getElementById("premiumBtn").addEventListener("click", () => {
  chrome.tabs.create({ url: "https://yoursite.com/premium" });
});

init();
