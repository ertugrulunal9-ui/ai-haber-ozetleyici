// Haber sayfasından makale metnini ve başlığını çıkarır

export function extractArticle() {
  const title = getTitle();
  const text = getBodyText();
  if (!text || text.length < 200) return null;
  return { title, text: text.slice(0, 4000) }; // Token tasarrufu için kırp
}

function getTitle() {
  return (
    document.querySelector("h1")?.innerText ||
    document.querySelector('meta[property="og:title"]')?.content ||
    document.title ||
    ""
  ).trim();
}

function getBodyText() {
  // Önce semantik etiketleri dene
  const selectors = [
    "article",
    '[class*="article-body"]',
    '[class*="article-content"]',
    '[class*="news-content"]',
    '[class*="post-content"]',
    "main",
  ];

  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) {
      const text = cleanText(el.innerText);
      if (text.length > 200) return text;
    }
  }

  // Fallback: en uzun <p> bloğu
  const paragraphs = [...document.querySelectorAll("p")]
    .map((p) => p.innerText.trim())
    .filter((t) => t.length > 50);

  return paragraphs.join(" ");
}

function cleanText(raw) {
  return raw
    .replace(/\s+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}
