// Supabase Edge Function ile iletişim

const EDGE_URL = "https://rvcvocdrcymiagulguvo.supabase.co/functions/v1/summarize";

const HEADERS = {
  "Content-Type": "application/json",
  "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2Y3ZvY2RyY3ltaWFndWxndXZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMxMzIyMTUsImV4cCI6MjA4ODcwODIxNX0.0j0sryRDILRFRdcpxK2aMECLshWpevr2BWyiwgKHI1w",
  "X-App-Secret": "aoz_9XkPq21_Zz98_Lmn777",
};

export async function summarize({ text, title, lang, deviceId }) {
  const res = await fetch(EDGE_URL, {
    method: "POST",
    headers: HEADERS,
    body: JSON.stringify({ action: "summarize", text, title, lang, deviceId }),
  });

  if (res.status === 429) return { error: "limit" };
  if (!res.ok) return { error: "generic" };

  const data = await res.json();
  return { summary: data.summary, sources: data.sources || [] };
}

export async function analyzeBias({ text, title, lang, deviceId }) {
  try {
    const res = await fetch(EDGE_URL, {
      method: "POST",
      headers: HEADERS,
      body: JSON.stringify({ action: "analyze", text, title, lang, deviceId }),
    });
    if (res.status === 429) return { error: "limit" };
    if (!res.ok) return { error: "generic" };
    return await res.json();
  } catch {
    return { error: "network" };
  }
}

export async function getVotes({ url, deviceId }) {
  try {
    const res = await fetch(EDGE_URL, {
      method: "POST",
      headers: HEADERS,
      body: JSON.stringify({ action: "getvotes", url, deviceId }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export async function submitVote({ url, deviceId, is_clickbait }) {
  try {
    const res = await fetch(EDGE_URL, {
      method: "POST",
      headers: HEADERS,
      body: JSON.stringify({ action: "vote", url, deviceId, is_clickbait }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export async function askQuestion({ text, title, lang, deviceId, question }) {
  const res = await fetch(EDGE_URL, {
    method: "POST",
    headers: HEADERS,
    body: JSON.stringify({ action: "ask", text, title, lang, deviceId, question }),
  });

  if (res.status === 429) return { error: "limit" };
  if (!res.ok) return { error: "generic" };

  const data = await res.json();
  return { answer: data.answer };
}
