// Google News RSS ile aynı konuda ilgili haber kaynakları

const RSS_BASE = "https://news.google.com/rss/search?hl=tr&gl=TR&ceid=TR:tr&q=";

export async function fetchRelatedSources(title) {
  if (!title) return [];

  const query = encodeURIComponent(title.slice(0, 60));
  const url = `${RSS_BASE}${query}`;

  try {
    const res = await fetch(url);
    const text = await res.text();
    return parseRSS(text).slice(0, 4); // En fazla 4 kaynak
  } catch {
    return [];
  }
}

function parseRSS(xml) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, "text/xml");
  const items = [...doc.querySelectorAll("item")];

  return items.map((item) => ({
    title: item.querySelector("title")?.textContent || "",
    link: item.querySelector("link")?.textContent || "",
    source: item.querySelector("source")?.textContent || "",
  }));
}
