// Cihaz ID yönetimi ve kullanım limiti takibi

const DAILY_LIMIT = 10;

export async function getDeviceId() {
  const { deviceId } = await chrome.storage.local.get("deviceId");
  if (deviceId) return deviceId;
  const newId = crypto.randomUUID();
  await chrome.storage.local.set({ deviceId: newId });
  return newId;
}

export async function getLang() {
  const { lang } = await chrome.storage.local.get("lang");
  return lang || "tr";
}

export async function setLang(lang) {
  await chrome.storage.local.set({ lang });
}

export async function getRemainingUsage() {
  const today = new Date().toDateString();
  const { usage } = await chrome.storage.local.get("usage");
  if (!usage || usage.date !== today) return DAILY_LIMIT;
  return Math.max(0, DAILY_LIMIT - usage.count);
}

export async function decrementUsage() {
  const today = new Date().toDateString();
  const { usage } = await chrome.storage.local.get("usage");
  const count = usage?.date === today ? usage.count + 1 : 1;
  await chrome.storage.local.set({ usage: { date: today, count } });
}

export async function saveToHistory(item) {
  const { summaryHistory = [] } = await chrome.storage.local.get("summaryHistory");
  const updated = [item, ...summaryHistory].slice(0, 10);
  await chrome.storage.local.set({ summaryHistory: updated });
}

export async function getHistory() {
  const { summaryHistory = [] } = await chrome.storage.local.get("summaryHistory");
  return summaryHistory;
}
