// Sayfa içeriğini çıkarır ve popup'a iletir

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "extract") {
    sendResponse(extractArticle());
  }
  return true;
});

function extractArticle() {
  const title = getTitle();
  const text = getBodyText();
  if (!text || text.length < 200) return null;
  return { title, text: text.slice(0, 4000), url: window.location.href };
}

function getTitle() {
  return (
    document.querySelector("h1")?.innerText ||
    document.querySelector('meta[property="og:title"]')?.content ||
    document.title ||
    ""
  ).trim();
}

function getBodyText() {
  const selectors = [
    "article",
    '[class*="article-body"]',
    '[class*="article-content"]',
    '[class*="news-content"]',
    '[class*="post-content"]',
    "main",
  ];

  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) {
      const text = cleanText(el.innerText);
      if (text.length > 200) return text;
    }
  }

  return [...document.querySelectorAll("p")]
    .map((p) => p.innerText.trim())
    .filter((t) => t.length > 50)
    .join(" ");
}

function cleanText(raw) {
  return raw.replace(/\s+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}

// ── Sidebar ──────────────────────────────────────────────────────────────────

async function sidebarFetch(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: "sidebarFetch", payload }, (response) => {
      if (response?.ok) resolve(response.data);
      else resolve(null);
    });
  });
}

async function initSidebar() {
  if (document.getElementById("aoz-sidebar")) return;

  const article = extractArticle();
  if (!article) return;

  const { lang = "tr", deviceId: storedId } = await chrome.storage.local.get(["lang", "deviceId"]);
  let deviceId = storedId;
  if (!deviceId) {
    deviceId = crypto.randomUUID();
    await chrome.storage.local.set({ deviceId });
  }

  const T = lang === "tr"
    ? {
        summarize: "Özetle", summarizing: "Özetleniyor...",
        label_summary: "ÖZET", label_qa: "SORU SOR",
        back: "Tekrar özetle",
        copy: "📋 Kopyala", copied: "✓ Kopyalandı",
        twitter: "𝕏 Paylaş",
        qa_placeholder: "Bu haber hakkında bir şey sor...",
        error: "Hata oluştu, tekrar dene.",
        bias_btn: "⚖ Taraflılık Analizi", bias_loading: "Analiz ediliyor...",
        bias_title: "TARAFLILIK ANALİZİ",
        bias_left: "Sol", bias_right: "Sağ",
        bias_objective: "Nesnel", bias_emotional: "Duygusal",
        bias_labels: ["Güçlü sol", "Sol eğilimli", "Merkez", "Sağ eğilimli", "Güçlü sağ"],
        bias_emo_labels: ["Nesnel", "Kısmen duygusal", "Duygusal"],
        clickbait_title: "CLICKBAIT MI?",
        clickbait_yes: "👎 Clickbait",
        clickbait_no: "👍 Değil",
        clickbait_first: "İlk oyu sen ver",
        clickbait_stats: (y, n) => `${y} clickbait · ${n} değil`,
      }
    : {
        summarize: "Summarize", summarizing: "Summarizing...",
        label_summary: "SUMMARY", label_qa: "ASK",
        back: "Summarize again",
        copy: "📋 Copy", copied: "✓ Copied",
        twitter: "𝕏 Share",
        qa_placeholder: "Ask about this article...",
        error: "Something went wrong.",
        bias_btn: "⚖ Bias Analysis", bias_loading: "Analyzing...",
        bias_title: "BIAS ANALYSIS",
        bias_left: "Left", bias_right: "Right",
        bias_objective: "Objective", bias_emotional: "Emotional",
        bias_labels: ["Far left", "Left-leaning", "Center", "Right-leaning", "Far right"],
        bias_emo_labels: ["Objective", "Somewhat emotional", "Emotional"],
        clickbait_title: "CLICKBAIT?",
        clickbait_yes: "👎 Clickbait",
        clickbait_no: "👍 Not clickbait",
        clickbait_first: "Be the first to vote",
        clickbait_stats: (y, n) => `${y} clickbait · ${n} not clickbait`,
      };

  const iconUrl = chrome.runtime.getURL("icons/icon48.png");

  const sidebar = document.createElement("div");
  sidebar.id = "aoz-sidebar";
  sidebar.innerHTML = `
    <div class="aoz-header">
      <div class="aoz-logo-row">
        <img src="${iconUrl}" class="aoz-icon" />
        <span class="aoz-logo-text">AI Özet</span>
      </div>
      <button class="aoz-close-btn" title="Kapat">✕</button>
    </div>
    <div class="aoz-body">
      <div class="aoz-main-view">
        <button class="aoz-btn-primary">${T.summarize}</button>
      </div>
      <div class="aoz-loading-view aoz-hidden">
        <div class="aoz-spinner"></div>
        <p class="aoz-loading-text">${T.summarizing}</p>
      </div>
      <div class="aoz-result-view aoz-hidden">
        <p class="aoz-label">${T.label_summary}</p>
        <p class="aoz-summary-text"></p>

        <div class="aoz-share-row">
          <button class="aoz-share-btn aoz-copy-btn">${T.copy}</button>
          <button class="aoz-share-btn aoz-twitter-btn">${T.twitter}</button>
        </div>

        <button class="aoz-bias-btn">${T.bias_btn}</button>
        <div class="aoz-bias-section aoz-hidden">
          <p class="aoz-label">${T.bias_title}</p>
          <div class="aoz-bias-meter">
            <div class="aoz-bias-meter-labels">
              <span>${T.bias_left}</span>
              <span class="aoz-bias-political-value"></span>
              <span>${T.bias_right}</span>
            </div>
            <div class="aoz-bias-bar aoz-political-bar">
              <div class="aoz-bias-dot aoz-political-dot"></div>
            </div>
          </div>
          <div class="aoz-bias-meter">
            <div class="aoz-bias-meter-labels">
              <span>${T.bias_objective}</span>
              <span class="aoz-bias-emotional-value"></span>
              <span>${T.bias_emotional}</span>
            </div>
            <div class="aoz-bias-bar aoz-emotional-bar">
              <div class="aoz-bias-dot aoz-emotional-dot"></div>
            </div>
          </div>
          <p class="aoz-bias-note aoz-hidden"></p>
        </div>

        <div class="aoz-clickbait-section">
          <p class="aoz-label">${T.clickbait_title}</p>
          <div class="aoz-vote-row">
            <button class="aoz-vote-btn aoz-vote-yes-btn"></button>
            <button class="aoz-vote-btn aoz-vote-no-btn"></button>
          </div>
          <p class="aoz-vote-stats">${T.clickbait_first}</p>
        </div>

        <div class="aoz-qa-section">
          <p class="aoz-label">${T.label_qa}</p>
          <div class="aoz-qa-row">
            <input class="aoz-qa-input" type="text" placeholder="${T.qa_placeholder}" />
            <button class="aoz-qa-btn">→</button>
          </div>
          <p class="aoz-qa-answer aoz-hidden"></p>
        </div>

        <button class="aoz-back-btn">${T.back}</button>
      </div>
    </div>
  `;
  document.body.appendChild(sidebar);

  const tab = document.createElement("button");
  tab.id = "aoz-tab";
  tab.textContent = "AI Özet";
  tab.classList.add("aoz-hidden");
  document.body.appendChild(tab);

  const mainView = sidebar.querySelector(".aoz-main-view");
  const loadingView = sidebar.querySelector(".aoz-loading-view");
  const resultView = sidebar.querySelector(".aoz-result-view");
  let currentSummary = "";

  function showView(name) {
    mainView.classList.toggle("aoz-hidden", name !== "main");
    loadingView.classList.toggle("aoz-hidden", name !== "loading");
    resultView.classList.toggle("aoz-hidden", name !== "result");
  }

  sidebar.querySelector(".aoz-close-btn").addEventListener("click", () => {
    sidebar.classList.add("aoz-hidden");
    tab.classList.remove("aoz-hidden");
  });

  tab.addEventListener("click", () => {
    sidebar.classList.remove("aoz-hidden");
    tab.classList.add("aoz-hidden");
  });

  sidebar.querySelector(".aoz-back-btn").addEventListener("click", () => showView("main"));

  // Özetle
  sidebar.querySelector(".aoz-btn-primary").addEventListener("click", async () => {
    const btn = sidebar.querySelector(".aoz-btn-primary");
    showView("loading");
    sidebar.querySelector(".aoz-loading-text").textContent = T.summarizing;

    try {
      const data = await sidebarFetch({ action: "summarize", text: article.text, title: article.title, lang, deviceId });
      if (!data?.summary) throw new Error();

      currentSummary = data.summary;
      sidebar.querySelector(".aoz-summary-text").textContent = data.summary;
      sidebar.querySelector(".aoz-qa-answer").classList.add("aoz-hidden");
      sidebar.querySelector(".aoz-qa-input").value = "";
      showView("result");

      // Oy durumunu yükle
      updateVoteBtns(T.clickbait_yes, T.clickbait_no, 0, 0);
      sidebarFetch({ action: "getvotes", url: article.url, deviceId }).then((votes) => {
        if (votes) updateVotes(votes);
      });

      const today = new Date().toDateString();
      const { usage } = await chrome.storage.local.get("usage");
      const count = usage?.date === today ? usage.count + 1 : 1;
      await chrome.storage.local.set({ usage: { date: today, count } });
    } catch {
      showView("main");
      btn.textContent = T.error;
      setTimeout(() => { btn.textContent = T.summarize; }, 2500);
    }
  });

  // Kopyala
  sidebar.querySelector(".aoz-copy-btn").addEventListener("click", async () => {
    if (!currentSummary) return;
    await navigator.clipboard.writeText(currentSummary);
    const btn = sidebar.querySelector(".aoz-copy-btn");
    btn.textContent = T.copied;
    setTimeout(() => { btn.textContent = T.copy; }, 2000);
  });

  // Twitter
  sidebar.querySelector(".aoz-twitter-btn").addEventListener("click", () => {
    if (!currentSummary) return;
    const text = encodeURIComponent(currentSummary.slice(0, 240) + " (AI Özet)");
    window.open(`https://twitter.com/intent/tweet?text=${text}`, "_blank");
  });

  // Soru Sor
  sidebar.querySelector(".aoz-qa-btn").addEventListener("click", async () => {
    const input = sidebar.querySelector(".aoz-qa-input");
    const question = input.value.trim();
    if (!question) return;

    const qaBtn = sidebar.querySelector(".aoz-qa-btn");
    const answerEl = sidebar.querySelector(".aoz-qa-answer");
    qaBtn.disabled = true;
    qaBtn.textContent = "...";

    try {
      const data = await sidebarFetch({ action: "ask", text: article.text, title: article.title, lang, deviceId, question });
      answerEl.textContent = data?.answer || T.error;
    } catch {
      answerEl.textContent = T.error;
    }

    qaBtn.disabled = false;
    qaBtn.textContent = "→";
    answerEl.classList.remove("aoz-hidden");
  });

  sidebar.querySelector(".aoz-qa-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") sidebar.querySelector(".aoz-qa-btn").click();
  });

  // Taraflılık Analizi
  sidebar.querySelector(".aoz-bias-btn").addEventListener("click", async () => {
    const btn = sidebar.querySelector(".aoz-bias-btn");
    btn.disabled = true;
    btn.textContent = T.bias_loading;

    const data = await sidebarFetch({ action: "analyze", text: article.text, title: article.title, lang, deviceId });

    btn.disabled = false;
    if (!data || data.error || data.political === undefined) {
      btn.textContent = T.error;
      setTimeout(() => { btn.textContent = T.bias_btn; }, 2000);
      return;
    }

    const polPct = ((data.political + 100) / 200 * 100).toFixed(1);
    const emoPct = Number(data.emotional).toFixed(1);
    sidebar.querySelector(".aoz-political-dot").style.left = `${polPct}%`;
    sidebar.querySelector(".aoz-emotional-dot").style.left = `${emoPct}%`;

    const polIdx = data.political < -60 ? 0 : data.political < -20 ? 1 : data.political <= 20 ? 2 : data.political < 60 ? 3 : 4;
    const emoIdx = data.emotional < 35 ? 0 : data.emotional < 65 ? 1 : 2;
    sidebar.querySelector(".aoz-bias-political-value").textContent = T.bias_labels[polIdx];
    sidebar.querySelector(".aoz-bias-emotional-value").textContent = `${T.bias_emo_labels[emoIdx]} (%${Math.round(data.emotional)})`;

    const noteEl = sidebar.querySelector(".aoz-bias-note");
    noteEl.textContent = data.note;
    noteEl.classList.remove("aoz-hidden");

    sidebar.querySelector(".aoz-bias-section").classList.remove("aoz-hidden");
    btn.classList.add("aoz-hidden");
  });

  // Clickbait oylama yardımcıları
  function updateVoteBtns(yesLabel, noLabel, clickbait, total) {
    const notClickbait = total - clickbait;
    sidebar.querySelector(".aoz-vote-yes-btn").textContent = `${yesLabel} (${clickbait})`;
    sidebar.querySelector(".aoz-vote-no-btn").textContent = `${noLabel} (${notClickbait})`;
  }

  function updateVotes({ total, clickbait, userVote }) {
    const notClickbait = total - clickbait;
    updateVoteBtns(T.clickbait_yes, T.clickbait_no, clickbait, total);
    sidebar.querySelector(".aoz-vote-stats").textContent =
      total === 0 ? T.clickbait_first : T.clickbait_stats(clickbait, notClickbait);
    sidebar.querySelector(".aoz-vote-yes-btn").classList.toggle("aoz-vote-active-yes", userVote === true);
    sidebar.querySelector(".aoz-vote-no-btn").classList.toggle("aoz-vote-active-no", userVote === false);
  }

  sidebar.querySelector(".aoz-vote-yes-btn").addEventListener("click", async () => {
    const data = await sidebarFetch({ action: "vote", url: article.url, deviceId, is_clickbait: true });
    if (data) updateVotes(data);
  });

  sidebar.querySelector(".aoz-vote-no-btn").addEventListener("click", async () => {
    const data = await sidebarFetch({ action: "vote", url: article.url, deviceId, is_clickbait: false });
    if (data) updateVotes(data);
  });
}

setTimeout(initSidebar, 1200);
