// Content script ile popup arasında köprü kurar

const AOZ_URL = "https://rvcvocdrcymiagulguvo.supabase.co/functions/v1/summarize";
const AOZ_KEY = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2Y3ZvY2RyY3ltaWFndWxndXZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMxMzIyMTUsImV4cCI6MjA4ODcwODIxNX0.0j0sryRDILRFRdcpxK2aMECLshWpevr2BWyiwgKHI1w";
const AOZ_SECRET = "aoz_9XkPq21_Zz98_Lmn777";

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "getArticle") {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      chrome.tabs.sendMessage(tab.id, { action: "extract" }, (result) => {
        if (chrome.runtime.lastError) { sendResponse(null); return; }
        sendResponse(result || null);
      });
    });
    return true;
  }

  if (msg.action === "sidebarFetch") {
    fetch(AOZ_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": AOZ_KEY, "X-App-Secret": AOZ_SECRET },
      body: JSON.stringify(msg.payload),
    })
      .then((res) => res.json())
      .then((data) => sendResponse({ ok: true, data }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
});
